#include "pfpsim/pfpsim.h"

int sc_main(int sc_argc, char* sc_argv[]) {
  return pfp_elab_and_sim(sc_argc, sc_argv);
}
