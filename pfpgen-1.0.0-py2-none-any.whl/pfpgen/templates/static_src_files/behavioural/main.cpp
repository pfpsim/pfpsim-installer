#include "pfpsim/pfpsim.h"

int pfp_main(int pfp_argc, char* pfp_argv[]) {

  pfp_start();  // Kickstart Simulation
  // Calling pfp_pause() from anywhere will return you on this line.

  return 0;
}
