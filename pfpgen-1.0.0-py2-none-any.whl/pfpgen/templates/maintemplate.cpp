#include "../behavioural/${topmodule.name}.h"

int pfp_main(int pfp_argc, char* pfp_argv[]) {
  // Construct All PE's & CE's
  auto Top = std::make_shared<${topmodule.name}>("${topmodule.name}");
  Top->init();  // Init all objects.

  sc_start();  // Kickstart Simulation
  // Calling sc_pause() from anywhere will return you on this line.

  return 0;
}
