Dependencies:
========================
Tenjin
ply 		(lex/yacc)
yaml 		(pyyaml)

sudo easy_install Tenjin
sudo easy_install ply
sudo easy_install pyyaml


PFPGEN
========================

Description about pfpgen goes here

Usage
-----

Clone this repository to get started. See behavior on how to use the FAD Compiler.

usage: pfpgen [-h] [--verbose] [--debug] [--nocache] input

positional arguments:
  input       The FAD file to compile

optional arguments:
  -h, --help  show this help message and exit
  --verbose   increase output verbosity
  --debug     increase output verbosity to debug
  --nocache   Turns of caching of files

Behavior
--------

Flexible invocation
*******************

The application can be run right from the source directory, in two different
ways:

1) Treating the pfpgen directory as a package *and* as the main script::

    $ python -m pfpgen [-h] [--verbose] [--debug] [--nocache] input

2) Using the pfpgenrun.py wrapper::

    $ ./pfpgenrun.py [-h] [--verbose] [--debug] [--nocache] input


